library(testthat)
library(rrbgen)

test_dir("rrbgen", reporter = "minimal", wrap = FALSE)
